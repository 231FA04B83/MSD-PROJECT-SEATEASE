const rooms = [
    {
      id: "1",
      roomNumber: "A101",
      name: "Ash",
      email: "ash@email.com",
      phone: "12345678",
      event: "Git and Github",
      date: "2021-01-21",
      duration: 2,
    },
    {
      id: "2",
      roomNumber: "A102",
      name: "Ash",
      email: "ash@email.com",
      phone: "12345678",
      event: "Git and Github",
      date: "2021-01-21",
      duration: 2,
    },
];
  
module.exports = rooms;