import "./Spinner.css";
const Spinner = () => {
  return <div id="spinner" />;
};
export default Spinner;
