$blackPreset = "#202120";
$pinkPreset = "#ff00ff";
